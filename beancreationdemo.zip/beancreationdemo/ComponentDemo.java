package com.niit.beancreationdemo;

public class ComponentDemo {

}
