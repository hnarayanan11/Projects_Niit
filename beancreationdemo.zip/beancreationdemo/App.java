package com.niit.beancreationdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        //HelloWorld helloworld=new HelloWorld();
        //System.out.println(helloworld.sayHello());
        //giving the responsibility to the spring container
        //beans.xml - bean definitions
        ApplicationContext context=new FileSystemXmlApplicationContext("beans.xml");
        HelloWorld helloWorld=(HelloWorld)context.getBean("helloWorld"); //name
        System.out.println(helloWorld);
        System.out.println(helloWorld.sayHello());
        HelloWorld helloWorld1=(HelloWorld)context.getBean(HelloWorld.class); //task
        System.out.println(helloWorld1);
        System.out.println(helloWorld1.sayHello());
    }
}
