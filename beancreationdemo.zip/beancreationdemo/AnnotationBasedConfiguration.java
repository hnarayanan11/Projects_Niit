package com.niit.beancreationdemo;

import org.springframework.context.ApplicationContext; 
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AnnotationBasedConfiguration {
	public static void main(String [] args){
		ApplicationContext context=new AnnotationConfigApplicationContext(BeanConfiguration.class);
		HelloWorld helloWorld=(HelloWorld)context.getBean("HW");
		System.out.println(helloWorld);
		System.out.println(helloWorld.sayHello());
		
	}
}
