package com.niit.beancreationdemo;

import org.springframework.stereotype.Component;

@Component
public class HelloWorld {
public String sayHello(){
	return "Welcome to the world of Spring Framework";
}
}
