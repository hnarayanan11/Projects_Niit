package com.iostream;

import java.io.*;

public class DeserialiationDemo {
public static void main(String[] args) {
	try{
		FileInputStream fis=new FileInputStream("E:/sample.txt");
		ObjectInputStream ois= new ObjectInputStream(fis);
		Employee emp=(Employee)ois.readObject();
		System.out.println("Employee ID: "+emp.getEmpId());
		System.out.println("Employee Name: "+emp.getEmpName());
		System.out.println("Employee Address: "+emp.getEmpAddr());
		System.out.println("Employee Address: "+emp.getPassword());ois.close();
	}catch(Exception e){System.out.println(e);}
}
}
