package com.iostream.ios;
import java.io.*;
public class BufferedStreamMethods {
	public static void main(String[] args) throws IOException{
		FileOutputStream fos=new FileOutputStream("F:/NIITECLIPSE/io's/bs.txt");
		BufferedOutputStream bos=new BufferedOutputStream(fos);
		String s="Welocome to file i/o operations rathish";
		byte []b=s.getBytes();
		bos.write(b);
		bos.close();fos.close();
		System.out.println("Success.....");
		FileInputStream fis=new FileInputStream("f:/niiteclipse/io's/bs.txt");
		BufferedInputStream bis=new BufferedInputStream(fis);
		int i;
		while((i=bis.read())!=-1){
			System.out.print((char)i);
		}bis.close();fis.close();
	}
}
