package com.iostream.ios;
import java.io.*;
public class SequenceStreamMethods {
	public static void main(String[] args) throws IOException{
		FileInputStream fis1=new FileInputStream("F:/NIITECLIPSE/io's/sample.txt");
		FileInputStream fis2=new FileInputStream("F:/NIITECLIPSE/io's/bs.txt");	
		FileOutputStream fos=new FileOutputStream("f:/niiteclipse/io's/ifs1.txt");
		SequenceInputStream sis=new SequenceInputStream(fis1, fis2);
		int i;
		while((i=sis.read())!=-1){
			fos.write(i);
			System.out.print((char)i);
		}sis.close();fis1.close();fis2.close();fos.close();
		FileInputStream fis=new FileInputStream("F:/NIITECLIPSE/io's/ifs1.txt");
		int j;
		while((j=fis.read())!=-1){
			System.out.print((char)j);
		}fis.close();
		
	}
}
