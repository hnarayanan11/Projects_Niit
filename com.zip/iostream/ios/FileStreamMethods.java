package com.iostream.ios;
import java.io.*;
public class FileStreamMethods {
	public static void main(String[] args) throws IOException{
		FileWriter fw=new FileWriter("f:/niiteclipse/io's/fw.txt");
		fw.write("Hi Java");
		fw.close();System.out.println("Success.......");
		FileReader fr=new FileReader("f:/niiteclipse/io's/fw.txt");
		int i;
		while((i=fr.read())!=-1){
			System.out.print((char)i);
		}fr.close();
	}
}
