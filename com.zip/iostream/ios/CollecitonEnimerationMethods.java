package com.iostream.ios;
import java.io.*;
import java.util.Enumeration;
import java.util.Vector;
public class CollecitonEnimerationMethods {
	public static void main(String[] args) throws IOException{
		FileInputStream fis1=new FileInputStream("F:/NIITECLIPSE/io's/sample.txt");
		FileInputStream fis2=new FileInputStream("F:/NIITECLIPSE/io's/bs.txt");	
		FileInputStream fis3=new FileInputStream("F:/NIITECLIPSE/io's/ifs1.txt");
		Vector v=new Vector<>();
		v.add(fis1);
		v.add(fis2);
		v.add(fis3);
		Enumeration e=v.elements();
		SequenceInputStream s=new SequenceInputStream(e);
		int i;
		while((i=s.read())!=-1){
			System.out.print((char)i);
		}s.close();fis3.close();fis2.close();fis1.close();
	}
}
