package com.iostream.ios;
import java.io.*;
public class ByteArrayMethods{
	public static void main(String[] args) throws IOException{
	FileOutputStream fos1=new FileOutputStream("f:/niiteclipse/io's/baos1.txt");
	FileOutputStream fos2=new FileOutputStream("f:/niiteclipse/io's/baos2.txt");
	ByteArrayOutputStream baos=new ByteArrayOutputStream();
	String s="Hi, this is java byte array output stream";
	byte[]b=s.getBytes();
	baos.write(b);
	baos.writeTo(fos1);
	baos.writeTo(fos2);
	System.out.println("Success...");
	baos.close();fos2.close();fos2.close();
	byte [] by={35,36,37,38};
	ByteArrayInputStream bais=new ByteArrayInputStream(by);
	int k=0;
	while((k=bais.read())!=-1){
		char ch=(char)k;
		System.out.print(ch+" "+k+" ");
	}bais.close();
	
	}
}
