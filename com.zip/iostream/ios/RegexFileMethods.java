/*package com.iostream.ios;
import java.util.regex.*;
import java.io.*;
public class RegexFileMethods {
	public static void main(String[] args)throws IOException {
		FileReader fr=new FileReader("f:/niitecclipse/io's/details.txt");
		Pattern p=Pattern.compile("[^a-zA-Z]?");
		int i;
		while((i=fr.read())!=-1){
			char c=(char)i;
			if(Pattern.matches("[^a-zA-Z]?", c)){
				System.out.println(c);
			}
		}
	}
}*/
