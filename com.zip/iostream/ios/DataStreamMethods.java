package com.iostream.ios;
import java.io.*;
public class DataStreamMethods {
	public static void main(String[] args) throws IOException {
		FileOutputStream fos1=new FileOutputStream("f:/niiteclipse/io's/abc.txt");
		DataOutputStream dos=new DataOutputStream(fos1);
		dos.writeInt(15);
		dos.write(65);
		dos.writeChars("Hi!");	
		System.out.println("Success............");dos.flush();fos1.flush();
		FileInputStream fis=new FileInputStream("f:/niiteclipse/io's/abc.txt");
		DataInputStream dis=new DataInputStream(fis);
		int i=dis.available();System.out.println(i);
		byte [] byt=new byte[i];
		dis.read(byt);
		for(byte bt:byt){
			char k=(char) bt;
			System.out.print(k+"");
		}
		fis.close();dis.close();dos.close();
	}
}
