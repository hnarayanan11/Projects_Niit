package com.iostream.ios;
import java.io.*;
public class FileOutStreamMethods {
	public static void main(String[] args) throws IOException{
		FileOutputStream fis=new FileOutputStream("F:/NIITECLIPSE/io's/ifs1.txt");	
		System.out.println("Enter the Words");
		fis.write(65);
		fis.close();
		System.out.println("Success.............");
		FileInputStream fos=new FileInputStream("F:/NIITECLIPSE/io's/ifs1.txt");
		int i=fos.read();
		System.out.println((char)i);
		fos.close();
		
	}
}
