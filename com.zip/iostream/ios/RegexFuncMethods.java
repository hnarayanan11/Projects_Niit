package com.iostream.ios;

import java.io.*;
import java.util.regex.*;
public class RegexFuncMethods {
	public static void main(String[] args) throws IOException{
		FileReader fr=new FileReader("F:/NIITECLIPSE/io's/details.txt");
		BufferedReader br=new BufferedReader(fr);
		String line;
		while((line=br.readLine())!=null){
			System.out.println("inside while loop");
			Pattern p=Pattern.compile("[0-9]{10}");
			Matcher m=p.matcher(line);
			while(m.find()){				
				System.out.println(m.group());
			}
		}br.close();
	}
}
