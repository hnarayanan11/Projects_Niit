package com.iostream;
import java.io.*;
public class iosMethod {
public static void main(String[] args) {
	try{
		FileInputStream ios=new FileInputStream("E:/sample.txt");
		int i=0;
		while((i=ios.read())!=-1){
			System.out.println((char)i);ios.close();
		}
	}catch(Exception e){System.out.println(e);}
}
}
