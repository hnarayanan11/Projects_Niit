/*package com.iostream;
import java.io.*;
public class IOInputstream {
public static void main(String[] args) {
	try{
		FileInputStream fis=new FileInputStream("E:/sample.txt");
		int avl=fis.read();
		byte[] buffer=avl;
		String s=new String(buffer);
		System.out.println("String "+s);
	}catch(Exception e){System.out.println(e);}
}
}
*/