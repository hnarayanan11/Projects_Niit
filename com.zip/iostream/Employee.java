package com.iostream;

import java.io.Serializable;

public class Employee implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String empId;
private String empName;
private String empAddr;
private transient String password; /*while using the transient key we can't see the value of the variable
*/
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmpId() {
	return empId;
}
public void setEmpId(String empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getEmpAddr() {
	return empAddr;
}
public void setEmpAddr(String empAddr) {
	this.empAddr = empAddr;
}

}
