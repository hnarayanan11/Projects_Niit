package com.iostream;
import java.io.*;
public class FileReaderDemo {
public static void main(String[] args) {
	try{
		FileReader reader=new FileReader("E:/sample.txt");
		char myContent[]=new char[200];
		reader.read(myContent);
		String str=new String(myContent);
		System.out.println(str);reader.close();
	}catch(Exception e){System.out.println(e);}
}
}
