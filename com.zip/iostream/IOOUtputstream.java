package com.iostream;

import java.io.*;

public class IOOUtputstream {
public static void main(String[] args) {
	String str="Hello! How are you?";
	try{FileOutputStream fos=new FileOutputStream("E:/sample.txt");
		for(int count=0;count<str.length();count++){
			fos.write(str.charAt(count));
		}
		System.out.println("Stored Successfully...");fos.close();
	}catch(Exception e){System.out.println(e);}
}
}
