package com.iostream;
import java.io.*;
public class serializeDemo {
public static void main(String[] args) {
	try{
		FileOutputStream fos= new FileOutputStream("E:/sample.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		Employee empl=new Employee();
		empl.setEmpId("E1001");
		empl.setEmpName("Sunil");
		empl.setEmpAddr("mumabai");
		empl.setPassword("Password");
		oos.writeObject(empl);
		System.out.println("object is written to a file:");oos.close();
	}catch(Exception e){System.out.println(e);}
}
}
