package com.niit;

public interface InterfaceMethod {
void on();
public void off();
abstract void charge();
}