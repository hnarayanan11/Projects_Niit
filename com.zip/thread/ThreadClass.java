package com.thread;

public class ThreadClass{
	public static void main(String[] args) {
		
		Thread currentThread=Thread.currentThread();
		
		System.out.println("Main Thread Details");
		System.out.println(currentThread.getName());
		System.out.println(currentThread.getPriority());
		/*after changing the name priority by the user*/
		currentThread.setName("MyMainThread");
		currentThread.setPriority(8);
		System.out.println(currentThread.getName());
		System.out.println(currentThread.getPriority());
	}
}
