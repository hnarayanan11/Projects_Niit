package com.thread;

public class RunnableImplMethod implements Runnable{
	public void run(){
		try {for(int i=0;i<5;i++){
		if(Thread.currentThread().isDaemon()){
			System.out.println(Thread.currentThread().getName()+" Daemn thread is running times");
		}
		else{	
			System.out.println(Thread.currentThread().getName()+" is running at times");
		}			
		Thread.sleep(100);		/*Thread.sleep(1000);*/
			
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
	}
	public static void main(String[] args) {
		RunnableImplMethod rim1=new RunnableImplMethod();
		RunnableImplMethod rim2=new RunnableImplMethod();
		Thread t1=new Thread(rim1,"firstThread");t1.setPriority(Thread.NORM_PRIORITY);
		Thread t2=new Thread(rim2,"secondThread");
		Thread t3=new Thread(rim2,"thirdThread");
		t1.setPriority(Thread.MIN_PRIORITY);t3.setPriority(Thread.NORM_PRIORITY);t3.setPriority(Thread.MAX_PRIORITY);
		t1.start();
		try{t1.join();}catch(Exception e){System.out.println(e);}	
		t2.setDaemon(true);
		t2.start();t3.start();		
		System.out.println(Thread.currentThread().getName()+" "+Thread.currentThread().getPriority());
	}
}
