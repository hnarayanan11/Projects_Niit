package com.thread;

public class ThreadMehtods extends Thread{
	public void finalize(){System.out.println("object is garbage collected");}  
	public void run(){
		try{
		for(int i=0;i<10;i++){
		System.out.println(Thread.currentThread().getName()+" "+i);
		
		Thread.sleep(500); /*Thread.currentThread().interrupt();System.out.println(Thread.currentThread().isInterrupted());*/
		
		}}catch(Exception e){System.out.println(e);}
	}
	public static void main(String[] args) {
		ThreadMehtods tm1=new ThreadMehtods();tm1.setName("firstThread");
		ThreadMehtods tm2=new ThreadMehtods();tm2.setName("secondThread");
		ThreadMehtods tm3=new ThreadMehtods();tm3.setName("thirdThread");
		ThreadMehtods tm4=new ThreadMehtods();tm4.setName("fourthThread");
		tm1.start();tm2.start();tm3.start();
		tm1.suspend();tm1.resume();
		tm4=null;
		System.gc();
	}
}
