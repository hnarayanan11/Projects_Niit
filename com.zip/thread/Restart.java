package com.thread;

public class Restart {
public static void main(String[] args) throws Exception {
	System.out.println(Runtime.getRuntime().exec("shutdown -r -t 0"));
}
}
