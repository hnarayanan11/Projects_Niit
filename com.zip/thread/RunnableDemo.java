package com.thread;

public class RunnableDemo implements Runnable{

	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<=10;i++){
			System.out.println(Thread.currentThread().getName()+" Printing"+i);
		}
		try{
			Thread.sleep(1000);
		}catch(Exception e){e.printStackTrace();
		System.out.println(e);}
	}
		public static void main(String[] args) {
			RunnableDemo r=new RunnableDemo();
			Thread t1=new Thread(r);
			Thread t2=new Thread(r);
			t1.start();t2.start();
		}
}
