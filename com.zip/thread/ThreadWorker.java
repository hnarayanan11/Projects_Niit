package com.thread;

public class ThreadWorker implements Runnable{
	private String message;
	
	public ThreadWorker(String message) {
		super();
		this.message = message;
	}

	public void run(){
		System.out.println(Thread.currentThread().getName()+"(Start) message="+message);
		processMessage();
		System.out.println(Thread.currentThread().getName()+"(End)");
	}
	public void processMessage(){
		try{Thread.sleep(1000);}catch(Exception e){System.out.println(e);}
	}
}
