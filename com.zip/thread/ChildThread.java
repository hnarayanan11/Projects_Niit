package com.thread;

public class ChildThread extends Thread{
	public void run(){
		for(int i=0;i<=10;i++)
		System.out.println(Thread.currentThread().getName()+":"+i);
		try{Thread.sleep(1000);}catch(Exception e){System.out.println(e);}
	}
public static void main(String[] args) {
	ChildThread ct1=new ChildThread();
	ChildThread ct2=new ChildThread();
	ct1.setName("Rathis");
	ct2.setName("Hari");
	ct1.start();	ct2.start();	
}
}
