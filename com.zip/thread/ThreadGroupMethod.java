package com.thread;

public class ThreadGroupMethod extends Thread{

}
