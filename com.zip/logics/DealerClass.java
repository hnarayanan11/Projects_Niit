package com.logics;

public class DealerClass {
 String Dname,Daddr,Fname,Grades;
 int Pricepkg;
public DealerClass(String dname, String daddr, String fname, String grades, int pricepkg) {
	super();
	Dname = dname;
	Daddr = daddr;
	Fname = fname;
	Grades = grades;
	Pricepkg = pricepkg;
}
 
}
