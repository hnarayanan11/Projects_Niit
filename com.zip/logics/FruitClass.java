package com.logics;

import java.util.*;

public class FruitClass {
public static void main(String[] args) {
	ArrayList<DealerClass> ds=new ArrayList<DealerClass>();
	Scanner s=new Scanner(System.in);
	String un,uad,dn,dad,fn,c,g;
	int fid,qty,ch = 0,ppkg,i=0;
	do{
		System.out.println("1. Dealer"
				+ "2. User");
		ch=s.nextInt();
		switch(ch){
		case 1:
			abc: System.out.println("Enter the Dealer Name and Address");
			dn=s.next(); dad=s.next();
			System.out.println("Enter the furit name, gradues, priceperkag");
			fn=s.next();g=s.next();ppkg=s.nextInt();
			DealerClass delcls=new DealerClass(dn, dad, fn, g, ppkg);
			ds.add(i++,delcls);
			System.out.println("Do you want to continue?(Y/N)");
			c=s.next();if(c.equalsIgnoreCase("Y")){
				System.out.println("You are continued...");
				/*continue abc;*/
			}else{System.out.println("thank you for register with us.");break;}	
		case 2:
			System.out.println("List");
			for(DealerClass obj:ds){
				System.out.println(i+++" "+obj.Fname+" "+obj.Grades+" "+obj.Pricepkg);
			}
			System.out.println("Enter the id to cart:");
			fid=s.nextInt();
			System.out.println(ds.listIterator(fid));
		break;
		}System.out.println("Do you want to contine?(Y/N)");
		c=s.next();		
	}while(c.equalsIgnoreCase("Y"));
}
}
