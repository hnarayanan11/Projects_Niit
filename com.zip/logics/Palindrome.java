package com.logics;

import java.util.Scanner;

class PalindromeMethods{
	public void Number(int a){
		int b,c=0,d;
		b=a;
		while(a>0){d=a%10;c=c*10+d;a=a/10;}
		if(c==b){System.out.println("The Entered Number is Palindrome");}
		else{System.out.println("The Entered String is Not Palidrome");}
	}
	public void StringWord(String str1){
		String str2="";int len=str1.length();
		System.out.println("Length:"+len);
		for(int i=len-1;i>=0;i--){
			str2+=str1.charAt(i);
		}
		if(str1.equalsIgnoreCase(str2)){System.out.println("The Entered String is Palidrome");}
		else{System.out.println("The Entered String is Not Palidrome");}
	}
}
public class Palindrome {
public static void main(String[] args) {
	PalindromeMethods pm=new PalindromeMethods();
	Scanner s=new Scanner(System.in);
	String s1="";int ch,n;
	System.out.println("\t\t\t  Palindrome Checking"
					+ "\n\t\t\t _*_*_*_*_*_*_*_*_*_*_");
	do{
		System.out.println("Enter the Your Choice to Check the Palidrome"
				+ "\n\t\t 1.Number Palindrome"
				+ "\n\t\t 2.Stirng Paindrome"
				+ "\n\t\t 3.Exit");ch=s.nextInt();
		switch (ch){
		case 1:
			System.out.println("Enter the Palidrome Number:");n=s.nextInt();
			pm.Number(n);
		break;
		case 2:
			System.out.println("Enter the String to check the Palindrome:");s1=s.next();
			pm.StringWord(s1);
		break;
		default: System.out.println("Exit");
		break;	
		}
	}while(ch<3);s.close();
}
}