package com.zoho;

import java.util.Scanner;

public class PalindromeNumberCheckMthd {
	public static void main(String[] args) {
		int n=0;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the check whether its palindrome or not");
		n=s.nextInt();
		int a,b,c=0;
		a=n;
		while(n>0){
			b=n%10;
			c=c*10+b;
			n=n/10;
		}
		if(c==a)
			System.out.println("The entered number is palidrome");
		else
			System.out.println("The entered number is not palidrome");
		s.close();
	}
}
