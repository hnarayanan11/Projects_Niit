package com.zoho;

public class FirstLastElementArrayMthd {
	public static void main(String[] args) {
		int a[]={10,25,14,35,98,12,32,29,20,15,100,90,8,80,70,18,19,16,5};
		System.out.println(" The Fisrt Element of Array is:"+a[0]+
				"\n The Last Elemetn of Array is:"+a[a.length-1]);
	}
}
