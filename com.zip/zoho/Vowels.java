package com.zoho;

public class Vowels {
	public static void main(String[] args) {
		String s="English Language";
		char []c=s.toCharArray();System.out.println(c[c.length-1]);
		int j,a = 0,e = 0,i=0,o=0,u=0;
		for(j=0;j<=c.length-1;j++){
			switch(c[j]){
			case 'a'|'A':
				a+=1;
			break;
			case 'e'|'E':
				e+=1;
			break;
			case 'i'|'I':
				i+=1;
			break;
			case 'o'|'O':
				o+=1;
			break;
			case 'u'|'U':
				u+=1;
			break;
			}
		}System.out.println("A occured "+a+" times, E occured "+e+" times, I occured "+i+" times, O occured "+o+" times and U occured "+u+" times.");
	}
}
