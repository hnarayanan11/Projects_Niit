package com.zoho;

public class EvenNumbers {
	public static void main(String[] args) {
		System.out.println("\t\t Even Numebrs From 1 To 100"
						 + "\n\t\t _*_*_*_*_*_*_*_*_*_*_*_*_*_");
		for(int i=1;i<=100;i++){
			if(i%2==0)
				System.out.print(i+" ");
			if(i%2!=0)
				System.out.println(i+" ");
		}
	}
}
