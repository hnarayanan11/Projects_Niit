package com.zoho;

import java.util.regex.*;

public class CharCountMethod {
	public static void main(String[] args) {
		String s="Hello_World! 1234567890 @#!$%^&*()!";
		int count=0,alphabetic=0,digit=0,space=0,bmp=0,special=0;
		for(int i=0;i<s.length();i++){
			if(Character.isLetter(s.charAt(i)))
				count++;
			if(Character.isAlphabetic(s.charAt(i)))
				alphabetic++;
			if(Character.isDigit(s.charAt(i)))
				digit++;
			if(Character.isWhitespace(s.charAt(i)))
				space++;
			if(Character.isBmpCodePoint(s.charAt(i)))
				bmp++;
		}
		Pattern p=Pattern.compile("[^a-zA-Z0-9]");
		Matcher m=p.matcher(s);
		while(m.find())
			special++;
		System.out.println("Special characters in a string:"+special);
		System.out.println("Characters are:"+ count+"\nAlphabetics are:"+ alphabetic+"\nDigits are:"+ digit+"\nSpaces are:"+ space
				+"\nBmpcodepoints are:"+ bmp);
	}
}
