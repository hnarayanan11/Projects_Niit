package com.zoho;

public class MinMaxArrayMthd {
	public static void main(String[] args) {
		int a[]={10,50,30,40,25,15,0,80,90,140,70,75};
		int max=a[0],min=a[0];
		for(int i=1;i<a.length;i++)
			if(a[i]>max)
				min=a[i];
		for(int i=1;i<a.length;i++)
			if(a[i]<min)
				min=a[i];
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
		System.out.println("Minimum value:"+min+" Maximum value:"+max);
	}
}
