package com.zoho;

import java.util.Scanner;

public class SwapMethod {
	public static void main(String[] args) {
		int a=0,b=0;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the A and B value to Swap:");
		a=s.nextInt();b=s.nextInt();
		System.out.println("Before Swap A:"+a+" B:"+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("after Swap A:"+a+" B:"+b);
		s.close();
	}
}
