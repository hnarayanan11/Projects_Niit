package com.zoho;

import java.util.Arrays;

public class AssendingDesending {
	public static void main(String[] args) {
		int a[]={15,3,8,17,9,0},temp=0;
		System.out.println("\t\t Array Sorting"
						+ "\n\t\t _*_*_*_*_*_*_"
						+ "\n Assending Order");
		Arrays.sort(a);
		for(int i=0;i<a.length;i++){
			System.out.print(a[i]+" ");
		}System.out.println();
		for(int i=0;i<a.length;i++){
			for(int j=0;j<a.length;j++){
				if(a[i]>a[j]){
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}				
			}
		}
		for(int i=0;i<a.length;i++)
			System.out.print(a[i]+" ");
	}
}
