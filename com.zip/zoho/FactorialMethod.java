package com.zoho;

import java.util.Scanner;

public class FactorialMethod {
	public static void main(String[] args) {
		int fact=1,n=1;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the factorial number to calculate:");
		n=s.nextInt();
		if(n<=0){System.out.println("Number should be more than zero.");}
		else{
			while(n>0){
				fact*=n;
				n-=1;
			}
			System.out.println(fact);
		}
		s.close();		
	}
}
