package com.zoho;

import java.util.Scanner;

public class FibonacciSeriesMethod {
	public static void main(String[] args) {
		int a=0,b=1,c=0,n;
		System.out.println("Enter the number for fibonacci:");
		Scanner s=new Scanner(System.in);
		n=s.nextInt();
		System.out.print(a+" "+b+" ");
		c=a+b;
		while(c<n){			
			System.out.print(c+" ");
			a=b;
			b=c;
			c=b+a;
			s.close();
		}
	}
}
