package com.zoho;

import java.util.Scanner;

public class BiggestOfThreeNumbers {
	public static void main(String[] args) {
		int a,b,c;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the A, B, & C value to check whcih one is greater");
		a=s.nextInt();b=s.nextInt();c=s.nextInt();
		if(a>b && a>c)
			System.out.println("A is greate than B and C "+a+" "+b+" "+c);
		else if(b>a && b>c)
			System.out.println("B is greate than A and C "+b+" "+a+" "+c);
		else if(c>a && c>a)
			System.out.println("C is greate than A and B "+c+" "+a+" "+b);
		else
			System.out.println("The enetered numbers were equaled...");
		s.close();
	}
}
