package com.zoho;

import java.util.Scanner;

public class ListOfPrimeNumbers {
	public static boolean isPrime(int n){
		if(n<=1)
			return false;
		for(int i=2;i<n;i++)
			if(n%i==0)
				return false;
		return true;
	}
	public static void main(String[] args) {
		Scanner s=new  Scanner(System.in);
		int prime=0,limit=200;
		System.out.println("Enter the number to check Prime Number:");
		prime=s.nextInt();
		if(isPrime(prime))
			System.out.println("True");
		else
			System.out.println("False");
		System.out.println("\t\t Prime Numbers Between 100 to 200"
						+ "\n\t\t_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_");
		for(int i=100;i<limit;i++){
			if(i%2!=0 && i%3!=0 && i%5!=0 && i%7!=0 && i%11!=0 && i%13!=0)
				System.out.println(i);
		}s.close();
	}
}