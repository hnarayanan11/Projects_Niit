package com.zoho;

public class LoopPrintMethod {
public static void main(String[] args) {
	System.out.println("Printing 1 to 6 usng a loop");
	for(int i=1;i<=6;++i)
		System.out.print(i);
	System.out.println("\nPrinting 'Hello' string for 5 times using loop");
	for(int i=0;i<5;i++)
		System.out.print("Hello ");
}
}
