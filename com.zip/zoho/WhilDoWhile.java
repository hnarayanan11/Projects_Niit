package com.zoho;

public class WhilDoWhile {
	public static void main(String[] args) {
		int i=0;
		System.out.println("Do While Loop");
		do{			
			System.out.print("Before increment"+i+" ");
			i++;
			System.out.print("\nAfter Increment"+i+"\t");
		}while(i<5); //do while prints 0 to 10 because do while loop checks the conditions at the end of the loop, it compiles the loop atleast once even the condition is false
		System.out.println("\nWhile Loop");
		i=0;
		while(i<5){
			System.out.print(i+" ");
			i++;
			System.out.print(i+"\t");
		} //whille prints 0 to 9 only because while loop checks the condition at begining of the loop if the conditions false the loop is exit
	}
}
