package com.zoho;

import java.util.Scanner;

public class AverageArrayMethod {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int n,b = 0,c=0;
		System.out.println("Enter the Array Element:");
		n=s.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the Array Elements one by one");
		for(int i=0;i<n;i++)
			a[i]=s.nextInt();
		for(int i=0;i<n;i++)
			b+=a[i];
		c=b/a.length;
		System.out.println("Total of array:"+b);
		System.out.println("Average of array:"+c);
		s.close();
	}
}
