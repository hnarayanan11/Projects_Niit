package com.collections;
import java.util.*;
public class LinedListMethod {
	public static void main(String[] args) {
		List<Employee> ll=new LinkedList<Employee>();
		List<String> ll1=new LinkedList<String>();
		ll1.add("Employee1");ll1.add("Employee2");ll1.add("Employee3");
		((LinkedList<String>) ll1).addFirst("Sample2");
		((LinkedList<String>) ll1).addLast("Sample1");		
		Employee e1=new Employee(150, 1000000, "HI");
		ll.add(e1);
		System.out.println(ll1);
		Iterator<Employee> i=ll.iterator();
		while(i.hasNext()){
			Employee e=(Employee) i.next();
			System.out.println(e.RollNo+" "+e.EmpName+" "+e.Salary);
		}
		System.out.println(((LinkedList<String>) ll1).getFirst()+" \n"+((LinkedList<String>) ll1).getLast());
		System.out.println(ll1.contains("Sample1"));ll1.remove("Sample1");System.out.println(ll1.contains("Sample1"));
		System.out.println(ll1);
	}	
}