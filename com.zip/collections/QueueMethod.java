package com.collections;
import java.util.*;
public class QueueMethod {
public static void main(String[] args) {
	PriorityQueue<String> pq=new PriorityQueue<String>();
	pq.add("Sample1");pq.add("Sample2");pq.add("Sample3");pq.add("Sample4");pq.add("Sample5");pq.add("Sample6");
	System.out.println(pq);
	Iterator<String> i=pq.iterator();
	System.out.println("Iterator"
					 + "\n_*_*_*_*_");
	while(i.hasNext()){
		System.out.println(i.next());
	}
	System.out.println("For Each"
			 + "\n_*_*_*_*_");
	for(Object o:pq){
		System.out.println(o);
	}
	System.out.println(pq.poll());pq.remove();System.out.println("after deleting the element:"+pq);
	pq.offer("Sample2");System.out.println(pq);
}
}
