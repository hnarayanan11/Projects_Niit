package com.collections;
import java.util.*;
public class EmloyeeGenClass {
public static void main(String[] args) {	
	ArrayList<Employee> ale=new ArrayList<Employee>();
	Employee e1=new Employee(1001,25000,"Jhon");
	Employee e2=new Employee(1002,30000,"Vickram");
	Employee e3=new Employee(1003,35000,"Candy");
	ale.add(e1);ale.add(e2);ale.add(e3);	
	Iterator<Employee> ei=ale.iterator();
	System.out.println("Using While Loop");
	while(ei.hasNext()){
		Employee esd=(Employee)ei.next();
		System.out.println(esd.RollNo+" "+esd.EmpName+" "+esd.Salary+" ");
	}System.out.println("Using For Each Loop");
	for(Employee e:ale){
		System.out.println(e.RollNo+" "+e.EmpName+" "+e.Salary);
	}
	ale.trimToSize();int len=ale.lastIndexOf(ale);System.out.println(len);
}

}
