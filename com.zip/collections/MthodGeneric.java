package com.collections;
import java.util.*;
public class MthodGeneric {
	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("Smaple1");
		al.add("Sample2");
		System.out.println(al);
		al.remove(0);System.out.println(al);
		al.add(0,"Sample1");
		System.out.println(al);
		Iterator<String> it=al.iterator();
		while(it.hasNext()){System.out.println(it.next());}
	}
}
