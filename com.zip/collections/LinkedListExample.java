package com.collections;
import java.util.*;
public class LinkedListExample{
	public static void main(String[] args) {
		Queue<Employee> dq=new ArrayDeque<Employee>();
		Employee e1=new Employee(101,25000,"ahov");
		Employee e2=new Employee(102,75000,"bipw");
		Employee e3=new Employee(103,55000,"cjqx");
		Employee e4=new Employee(104,125000,"dkry");
		Employee e5=new Employee(105,525000,"elsz");
		Employee e6=new Employee(106,525000,"fmtz");
		Employee e7=new Employee(107,525000,"gnuz");
		dq.add(e1);dq.add(e2);dq.add(e3);dq.add(e4);dq.add(e5);dq.add(e6);dq.add(e7);
		for(Employee o:dq){
			System.out.println(o.RollNo+" "+o.EmpName+" "+o.Salary);
		}
		Employee e8=new Employee(108, 180000, "sample");
		dq.offer(e8);System.out.println("After using offer");
		for(Employee o:dq){
			System.out.println(o.RollNo+" "+o.EmpName+" "+o.Salary);
		}System.out.println("After remove()");dq.remove();
		for(Employee o:dq){
			System.out.println(o.RollNo+" "+o.EmpName+" "+o.Salary);
		}((ArrayDeque<Employee>) dq).offerFirst(e4);
		System.out.println("Adding offer first() ");
		for(Employee o:dq){
			System.out.println(o.RollNo+" "+o.EmpName+" "+o.Salary);
		}
	}
}