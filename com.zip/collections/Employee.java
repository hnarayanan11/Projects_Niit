package com.collections;

public class Employee {
int RollNo,Salary;
String EmpName;
public Employee(int rollNo, int salary, String empName) {
	super();
	RollNo = rollNo;
	Salary = salary;
	EmpName = empName;
}
}