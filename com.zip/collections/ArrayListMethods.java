package com.collections;
import java.util.*;
public class ArrayListMethods {
@SuppressWarnings("unchecked")
public static void main(String[] args) {
	ArrayList<String> al1=new ArrayList<String>();
	ArrayList<String> al2=new ArrayList<String>();
	ArrayList<String> al3=new ArrayList<String>();
	al1.add("Sample1");al1.add("Sample2");al1.add("Sample3");
	al2.add("1Sample");al2.add("2Sample");al2.add("3Sample");
	System.out.println(al1+"\n"+al2);
	al2.addAll(al1);
	System.out.println(al2);
	al1.removeAll(al2);
	System.out.println(al1+"\n"+al2);
	al1.addAll(al2);
	System.out.println(al1+"\n"+al2);
	al1.remove(0);al2.remove(1);
	System.out.println("Array List 1"+al1+"\nArray List 2"+al2);
	System.out.println("Array List 1"+al1+"\nArray List 2"+al2);
	System.out.println(al1.isEmpty());
	System.out.println(al1.contains("2Sample"));
	al1.addAll(al2);System.out.println(al1+"\n"+al2);
	al1.clear();al2.clear();System.out.println(al1.isEmpty()+" "+al2.isEmpty());
	al1.add(0, "String1");al1.add(0, "String2");al1.add(0, "String3");
	al2.add("String1");al2.add("String2");al2.add("String3");
	System.out.println(al1+"\n"+al2);
	System.out.println(al1.retainAll(al2));
	System.out.println(al1+"\n"+al2);
	al1.add("String");al1.add("String");al1.add("String");al1.add("String");
	al2.add("String");al2.add("String");al2.add("String");al2.add("String");
	System.out.println("ArrayList1"+al1+"\nArrayList2"+al2);

	al2.add("abcd");
	al1.add("efgh");	
	al1.retainAll(al2);
	al2.retainAll(al1);
	System.out.println("after retain ArrayList1"+al1+"\nArrayList2"+al2);
	System.out.println(al1.size()+" "+al2.size());	
	System.out.println(al1.lastIndexOf(al2));
	al3=(ArrayList<String>) al2.clone();
	System.out.println(al3);
}
}
