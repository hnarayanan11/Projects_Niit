package com.collections;
import java.util.*;
public class ArrayListCol {
	public static void main(String[] args) {
		ArrayList<String> s=new ArrayList<String>();		
		System.out.println("\t\t Collections");
		s.add("sample3");s.add("Sample0");s.add(1,"Sample2");s.add(0,"Sample1");
		System.out.println(s);
		for(Object o:s){System.out.println(o);}
		ArrayListCol alc=new ArrayListCol();
		System.out.println(alc.hashCode());
		int hc=1829164700;System.out.println(hc);
	}
}
