package com.collections.set;
import java.util.*;
public class HashMap {
	public static void main(String[] args) {
		/*Using to sort the keys by ascending order automatically once the object has stored to collection object*/
		TreeMap<Integer,StudentClass> hm=new TreeMap<Integer,StudentClass>();
		StudentClass sc1=new StudentClass(101, 450, "xxx");
		StudentClass sc2=new StudentClass(102, 475, "yyy");
		StudentClass sc3=new StudentClass(103, 425, "zzz");
		StudentClass sc4=new StudentClass(104, 490, "uuu");
		StudentClass sc5=new StudentClass(105, 498, "vvv");
		hm.put(310, sc1);hm.put(220, sc2);hm.put(430, sc3);
		System.out.println(hm.size()+" "+hm.isEmpty()+" "+hm.lastKey());
		for(Map.Entry<Integer, StudentClass> sc:hm.entrySet()){
			int key=sc.getKey();
			StudentClass cs=sc.getValue();
			System.out.println(key+"=");
			System.out.println(cs.id+" "+cs.name+" "+cs.mark);
		}
		hm.put(140,sc4);hm.put(50,sc5);
		System.out.println("After inserting all object to treemap collection object");
		for(Map.Entry<Integer, StudentClass> sc:hm.entrySet()){
			int key=sc.getKey();
			StudentClass cs=sc.getValue();
			System.out.print(key+"=");
			System.out.print(cs.id+" "+cs.name+" "+cs.mark+"\n");
		}
	}
}
