package com.collections.set;
import java.util.HashMap;
public class HashMapMethod {
	
	public static void main(String[] args) {
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		hm.put(1, "Hello");hm.put(2, "Hello");hm.put(3, "Hello");
		System.out.println(hm.size()+" "+hm.clone()+"\n"+hm);
		System.out.println(hm.get(1)+" "+hm.get(3)+" "+hm.entrySet()+" "+hm.remove(2)+" "+hm.entrySet());
		System.out.println(hm);
	}
}
