package com.collections.set;

public class Book {
public int id,quantity;
public String name;
public Book(int id, int quantity, String name) {
	super();
	this.id = id;
	this.quantity = quantity;
	this.name = name;
}

}
