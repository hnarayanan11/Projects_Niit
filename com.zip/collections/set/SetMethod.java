package com.collections.set;
import java.util.*;
public class SetMethod {
public static void main(String[] args) {
	HashSet<String> s=new HashSet<String>();
	s.add("Hello");s.add("Hi");s.add("Sample");
	System.out.println(s);
	for(Object o:s){System.out.println(o+" "+s.isEmpty());}
	System.out.println(s.size());s.remove("Hi");
	for(Object o:s){System.out.println(o+" "+s.isEmpty()+" "+s.size());}
}
}
