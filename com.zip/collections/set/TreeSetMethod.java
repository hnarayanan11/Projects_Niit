package com.collections.set;
import java.util.*;
public class TreeSetMethod {
public static void main(String[] args) {
	TreeSet<String> ts=new TreeSet<String>();
	ts.add("Sample5");ts.add("Sample4");ts.add("Sample3");ts.add("Sample1");ts.add("Sample2");
	System.out.println(ts.size()+" "+ts);
	/*ts.clear();*/System.out.println(ts.size()+" "+ts);
	HashSet<String> hs=new HashSet<>();
	hs.clear();
	System.out.println(hs.size()+" "+hs);
	ts.clone();System.out.println(ts.size()+" "+hs);
}
}
