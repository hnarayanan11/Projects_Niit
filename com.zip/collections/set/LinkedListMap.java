package com.collections.set;
import java.util.*;
public class LinkedListMap {
	public static void main(String[] args) {
		LinkedHashMap<Integer,String> llm=new LinkedHashMap<Integer,String>();
		System.out.println(llm.size()+" "+llm.isEmpty());
		llm.put(4, "Sample1");llm.put(1, "Sample2");llm.put(5, "Sample5");llm.put(5, "Sample3");llm.put(3, "Sample4");
		for(Map.Entry<Integer, String> mo:llm.entrySet()){
			int key=mo.getKey();String str=mo.getValue();
			System.out.println(key+"="+str);
		}
	}
}
