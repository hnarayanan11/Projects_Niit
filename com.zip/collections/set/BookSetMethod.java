package com.collections.set;
import java.util.*;
public class BookSetMethod {
public static void main(String[] args) {
	HashSet<Book> hs=new HashSet<Book>();
	HashSet<Book> hs2=new HashSet<Book>();
	System.out.println(hs.size());
	Book b1=new Book(101, 10, "Core JAVA Balaguruswamy");
	Book b2=new Book(101, 50, "CPP Balaguruswamy");
	hs.add(b1);hs.add(b2);
	for(Book b:hs){System.out.println(b.id+" "+b.quantity+" "+b.name+" "+hs.size());}
	hs2.addAll(hs);
	for(Book b:hs2){System.out.println(b.id+" "+b.quantity+" "+b.name+" "+hs.size());}
}
}
