package com.collections.set;
import java.util.*;
public class LinkedHashSetMethod {

	public static void main(String[] args) {
		LinkedHashSet<String> lhs=new LinkedHashSet<String>();
		lhs.add("Sample");lhs.remove("Sample");
		System.out.println(lhs);
		System.out.println("Empty: "+lhs.isEmpty()+" Size: "+lhs.size());
	}

}
