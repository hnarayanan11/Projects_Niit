package com.collections.set;

public class StudentClass {
	int id,mark;
	String name;
	public StudentClass(int id, int mark, String name){
		super();
		this.id=id;
		this.mark=mark;
		this.name=name;
	}
}