package com.regex;
import java.util.regex.*;
public class RegexMethod {
	public static void main(String[] args) {
		Pattern p=Pattern.compile(".s");//it's contains only two characters and ends with s
		Matcher m=p.matcher("as");
		boolean b1=m.matches();		
		System.out.println("The Matcher B1 is: "+b1);
		boolean b2=Pattern.compile(".a.").matcher("ha1").matches();//this is the 2nd way to checks the value
		System.out.println("The Matcher b2 is: "+b2);
		boolean b3=Pattern.matches(".12", "112");
		System.out.println("The Matcher b3 is: "+b3);
		System.out.println("using character stream: "+Pattern.matches("[abc]", "abc")+
				" "+Pattern.matches("[^123]", "78")+" "+Pattern.matches("[a-zA-z]", "b")+" "+
				"\nPattern using inner patter: "+Pattern.matches("[a-d[m-p]]","m")+" "+Pattern.matches("[A-Z][a-zA-Z]*", "Azzzz")
				+"\n Pattern using and gate: "+Pattern.matches("[a-z&&[def]]", "d")+" "+Pattern.matches("[a-z&&[^def]]", "a")
				+"\n Pattern using and gate with character stream: "+Pattern.matches("[a-z&&[^d-f]]", "d"));
		System.out.println("Pattern using Quantifiers: "+Pattern.matches("[abc]?", "a")+" "+Pattern.matches("[abc]+", "aaaaa")
		+"\n Pattern using Quantifiers: "+Pattern.matches("[abc]*", "")+" "+Pattern.matches("[abc]{0,}", ""));
		System.out.println("Password Length: "+Pattern.matches("[a-z]{6,12}", "zasdsert"));
		System.out.println("Patter using Metacharacters: "+Pattern.matches("\\d", "1")+" "+" "+Pattern.matches("\\w+", "a_a")+"\n Pattern using W: "
				+Pattern.matches("\\W+", "-=+")+"\n Bound Patter: "+Pattern.matches("\\b+", "Abcs abcd"));
	}
}