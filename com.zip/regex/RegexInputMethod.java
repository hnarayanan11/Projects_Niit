package com.regex;
import java.util.*;
import java.util.regex.*;
public class RegexInputMethod {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);	
	while(true){
	System.out.println("Enter the regex pattern:");
	Pattern p=Pattern.compile(s.nextLine());
	System.out.println("Enter the value");
	Matcher m=p.matcher(s.nextLine());
	boolean b=false;s.close();
		while(m.find()){
			System.out.println("i found the text "+m.group()+" starting at "+m.start()+" index and ending at "+m.end());
			b=true;		
		}
	if(!b){
		System.out.println("No match found");
	}
	}
}
}
