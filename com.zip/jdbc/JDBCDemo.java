package com.jdbc;
import java.sql.*;
import java.sql.DriverManager;
public class JDBCDemo {
public static void main(String[] args) {	
	
	try{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampleregis","root","root");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from registration");
		while(rs.next()){
			System.out.print(rs.getString("username")+" "+rs.getString("emailId"));
		}
	}catch(Exception e){System.out.println(e);}
	finally{
		System.out.println("after catch");		
	}
}
}
