package com.jdbc;
import java.sql.*;
public class h2jdbcMethod {
	public static void main(String[] args) {
		try{
			Class.forName("org.h2.Driver");
			Connection con=DriverManager.getConnection ("jdbc:h2:~/test18", "admin","root");
			Statement st=con.createStatement();
			st.executeUpdate("insert into sample values('Sample',123456)");
			System.out.println("Inserted Successfully");
		}catch(Exception e){System.out.println(e);}
	}
}
