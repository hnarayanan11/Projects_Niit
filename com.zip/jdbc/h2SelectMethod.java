package com.jdbc;
import java.sql.*;
public class h2SelectMethod {
	public static void main(String[] args) {
		try{
			Class.forName("org.h2.Driver");
			Connection con=DriverManager.getConnection("jdbc:h2:~/test18","admin","root");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from sample");
			while(rs.next()){
				System.out.println("Name     :"+rs.getString("username")
				+"\nNumber     :"+rs.getInt("mobileno"));
			}
		}catch(Exception e){System.out.println(e);}
	}
}
