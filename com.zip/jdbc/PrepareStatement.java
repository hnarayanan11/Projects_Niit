package com.jdbc;
import java.util.*;
import java.sql.*;

public class PrepareStatement {
public static void main(String[] args) {
	try{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taxi","root","root");
		PreparedStatement psmt=con.prepareStatement("insert into user values(?)");
		String user="";
		Scanner s=new Scanner(System.in);
		System.out.println("user 1");
		user=s.next();
		psmt.setString(1,user); int re=psmt.executeUpdate();
		if(re>0){System.out.println("Inserted Successfully");}
		else{System.out.println("not inserted");}
		Statement st=con.createStatement();
		st.executeUpdate("insert into user values('"+user+"')");
		System.out.println("Double tiiime inserted ");con.close();s.close();
	}catch(Exception e){System.out.println(e);}
}
}
