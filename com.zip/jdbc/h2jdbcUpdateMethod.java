package com.jdbc;
import java.sql.*;
import java.util.*;
public class h2jdbcUpdateMethod {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String name="";int mn=0;
		System.out.println("Enter the values of name and number");
		name=sc.next();mn=sc.nextInt();
		try{
			Class.forName("org.h2.Driver");
			Connection con=DriverManager.getConnection("jdbc:h2:~/test18","admin","root");
			Statement st=con.createStatement();
			st.executeUpdate("update sample set username='"+name+"' where mobileno='"+mn+"'");
			System.out.println("updated successfully");
		}catch(Exception e){System.out.println(e);}sc.close();
	}
}
