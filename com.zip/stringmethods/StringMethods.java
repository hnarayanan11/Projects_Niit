package com.stringmethods;
public class StringMethods {
	public static void main(String[] a) {
		String s="DBMS/Ramesh/2Mca",s1[];
		System.out.println(s);
		s1=s.split("\\/");
		System.out.println(s1[0]+" "+s1[1]+" "+s1[2]);
	}
}
