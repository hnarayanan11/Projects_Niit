package com.stringmethods;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.io.*;
public class StringMethodsManualMthds {
	public static void main(String[] args)throws IOException {
		String str="",rev="";
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String:");str=s.next();
		System.out.println("Entered String: "+str);
		int ch,b = 0;
		char c[]=str.toCharArray();
		do{
			System.out.println("Enter your choice to perform a Stirng operations using manaul:"
					+ "\n 1. Reverse a string"
					+ "\n 2. Palidrome checking"
					+ "\n 3. Concat"
					+ "\n 4. Anagram"
					+ "\n 5. Counting words");
			ch=s.nextInt();
			switch(ch){
			case 1:
				for(int i=c.length-1;i>=0;i--){
					System.out.print(c[i]);
				}
			break;
			case 2:		
				for(int i=c.length-1;i>=0;i--){
					rev+=c[i];
				}
				if(str.equals(rev))
					System.out.println("The entered string is "+str+" is palidrome");
				else
					System.out.println("The entered string is "+str+" is not palidrome");
			break;
			case 3:
				System.out.println("Enter the second string:");
				rev=s.next();
				rev=str+" "+rev;
				System.out.println(rev);
			break;
			case 4:
				String astr1="",astr2="";
				System.out.println("Enter the two string:");
				astr1=s.next();astr2=s.next();
				if(astr1.length()!=astr2.length()){
					System.out.println("The given strings are not anagram");break;
				}else{
					char as2;
					for(int i=0;i<=astr2.length()-1;i++){
						as2=astr2.charAt(i);
						for(int j=0;j<=astr1.length()-1;j++){
							if(as2==astr1.charAt(j)){
								b++;
							}
						}						
					}if(b==0){System.out.println("Entirely Different");break;}				
				}
				if(b!=astr1.length()){
					System.out.println("The given strings are anagram");
				}else{
					System.out.println("The given strings are not anagram");
				}
			break;
			case 5:
				System.out.println("Enter the string to be calculated");
				BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
				String st=br.readLine();
				int space=0;
				for(int i=0;i<st.length();i++){
					if(st.charAt(i)==' ')
						space++;
				}
				String arr[]=new String[space+1];
				String nstr="";
				for(int i=0,j=0;i<st.length();i++){
					if(st.charAt(i)==' '){
						arr[j]=nstr;
						j++;
						nstr="";
					}
					else{
						nstr=nstr+st.charAt(i);
					}
				arr[j]=nstr;
				}
				for(int i=0;i<arr.length;i++)
					System.out.println(arr[i]);
			break;
			}
		}while(ch<=6);
		
		
		s.close();
	}
}
