package com.stringmethods;

public class StringClass {
	public static void main(String[] args) {
		//Converting Character array to String
		char[] c={'h','e','l','l','o'};
		String s=new String(c);
		System.out.println(s);
		
		//Checking two strings
		String str1="Welcome";
		String str2=new String("Welcome");
		System.out.println(str2.equals(str1));//returns true
		String str3="Welcome",str5="welcome";String str7="This is the Sample Index";
		String str4=String.format("Message is: "+str3);String str8=str2.intern();
		String str6=String.format("Message is: %f",10.120); byte[] bs=str2.getBytes();
		char[] cs=new char[10];int ix1=str7.indexOf("Index"),ix3=str7.indexOf("is",4),ix2=str7.indexOf("is"),ix4=str7.indexOf('s');
		System.out.println("INDEX: "+ix1+" "+ix2+" "+ix3+" "+ix4);//returns the position of the string characters
		str1.getChars(0, 4, cs, 0);
		System.out.println(str1.equals(str3));//returns true Because the both are literals
		System.out.println(str1.equals(str5)+" After using ignorecase "+str1.equalsIgnoreCase(str5));
		System.out.println(str1.length());//returns the length of the 'str1' literal
		System.out.println(str1.charAt(5));//returns the 5 index character which is 'm'. Because string starts with 1
		System.out.println("Formatted "+str4);//returns the formatted string.
		System.out.println("Concat "+str1.concat(str5));//returns str1 append with str5
		System.out.println("Contains "+str3.contains(str5));//returns whether the two strings are equals are not including case
		System.out.println("Ends With "+str1.endsWith("e"));//returns whether the string ends with the specified character
		System.out.println("Starts wtih "+str2.startsWith("w"));//returns whether the string starts with the specified character
		System.out.println(str6);//returns the formatted string
		for(int i=0;i<bs.length;i++)System.out.println("getByte() "+bs[i]);//returns the byte of the string
		System.out.println(cs);//returns converted character from the string of 4 character
		System.out.println("String Intern() checking the equals");
		System.out.println(str8==str1);System.out.println("Checking from source string");//it's reference is same
		System.out.println(str8==str2);//its's reference is different
		System.out.println(str3.isEmpty());//returns true if it's empty
		String str9=String.join("-", "Welcom","to","String","Methods");//'-'is the delimiter
		System.out.println(str9); String str10="Hi, this is string to show the string method of replace",str11=str10.replace('i', 'e');//replace the characters by e instead of a
		String str12=str10.replace("is", "was");//replace the is from the string to was
		System.out.println(str11+"\n"+str12);String str14=str10.replaceAll("\\s", "-");//replace the string white space to '-'
		String str13=str10.replaceAll("s","t");//replaces the string only
		System.out.println(str13+"\n"+str14);String str15="Hello, How are you?";
		for(String sobj:str15.split("\\s"))//split's words by white space
			System.out.println(sobj);
		for(String sobj:str15.split("\\s",0))//split's only 0th position
			System.out.println(sobj);
		for(String sobj:str15.split("\\s",1))//split's only 1th position
			System.out.println(sobj);
		for(String sobj:str15.split("\\s",2))//split's only 2th position
			System.out.println(sobj);
		String str16="Hello and Hi",str17=str16.substring(5,10);//returns the substring of character 5 to 10
		System.out.println("sub string"+str17);
		String str18="NIIT";
		System.out.println(str18+" after removing ii"+str18.length());
		 str18=str18.replace("II", "");
		System.out.println(" after removing ii "+str18.length());
		str18=String.join("II", "N","T");
		System.out.println(str18);
		StringBuffer sb=new StringBuffer("Hello ");  
		sb.insert(1,"Java");//now original string is changed  
		System.out.println(sb);//prints HJavaello 
		sb.replace(1,3,"Java");  
		System.out.println(sb);//prints HJavalo  
		sb.delete(1, 3);//deleting the index from 1to3
		System.out.println(sb);
		sb.reverse();
		System.out.println("Reverse of string "+sb +" Ensuring the capacity of the string buffer object "+sb.capacity());
		sb.ensureCapacity(50);//add the capacity of the string buffer object
		System.out.println(sb+" "+sb.capacity());
		sb.append(str1);System.out.println(sb.reverse());
		StringBuilder sb2=new StringBuilder("Hello");
		sb2.delete(1,3);  
		System.out.println(sb2);//prints Hlo  
		StringBuilder sb3=new StringBuilder("Hello hari");
		StringBuilder sb4=new StringBuilder(sb3.substring(6));
		sb4.reverse();
		sb3.delete(6,10);
		sb3.append(sb4);System.out.println(sb3);
	}
}