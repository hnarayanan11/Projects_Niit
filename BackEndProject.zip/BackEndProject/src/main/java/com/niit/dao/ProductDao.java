package com.niit.dao;

import java.util.List;

import com.niit.model.Product;

public interface ProductDao {
	void saveProduct(Product product);
	void deleteProduct(Product product);
	void updateProduct(Product product);
	List<Product> getId(int id);
	List<Product> getAllProduct();	
}
