package com.niit.dao;

import java.util.List;

import com.niit.model.UserProcess;

public interface UserProcessDao {
	void saveUserProcess(UserProcess userProcess);
	void deleteUserProcess(UserProcess userProcess);
	void updateUserProcess(UserProcess userProcess);
	List<UserProcess> getId(int id);
}
