package com.niit.daoimpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.ProductDao;
import com.niit.model.Product;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDao {

	@Autowired
	private SessionFactory sessionFactory;
	public void saveProduct(Product product) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();/*org.hibernate*/
		System.out.println("ID: "+product.getId());
		session.save(product);
		System.out.println("ID: "+product.getId());
	}
	public void deleteProduct(Product product) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession(); /*org.hibernate*/
		System.out.println("ID: " + product.getId());
		session.delete(product);
	}
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();/*org.hibernate*/
		System.out.println("ID: "+product.getId());
		session.update(product);
		System.out.println("ID: "+product.getId());		
	}
	public List<Product> getId(int id) {
		// TODO Auto-generated method stub
		String query="FROM Product WHERE Id="+id;
		Session session=sessionFactory.openSession();
		Query q=session.createQuery(query); /*here Query from hibernate query*/
		List<Product> lp=q.list();
		return lp;
	}
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		String query="FROM Product";
		Session session=sessionFactory.openSession();
		Query q=session.createQuery(query);
		List<Product> lp=q.list();
		return lp;
	}
}
