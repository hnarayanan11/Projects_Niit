package com.niit.DemoProject;
import java.util.*;

import com.niit.temperaturerconverstion.TemparatureConversion;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Scanner s=new Scanner(System.in);
        float celcius = 0,fahrenhiet = 0;
        System.out.println("Enter the Celcius and Fahrenhiet values:");
        celcius=s.nextFloat(); fahrenhiet=s.nextFloat();
        TemparatureConversion.Fahrenheit(celcius);TemparatureConversion.Celsius(fahrenhiet);        
    }
}
