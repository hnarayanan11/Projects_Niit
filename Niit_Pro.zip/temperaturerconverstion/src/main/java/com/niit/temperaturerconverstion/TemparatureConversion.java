package com.niit.temperaturerconverstion;

public class TemparatureConversion {
	public static void Fahrenheit(float c){
		float f=c*9/5+32;
		System.out.println("Celsius "+c+" of Fahrenheit "+f);
	}
	public static void Celsius(float f){
		float c=(f-32)*5/9;
		System.out.println("Fahrenheit "+f+" of Celsius "+c);
	}
}
