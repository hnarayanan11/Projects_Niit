package com.niit.DependencyInjection;

import org.springframework.stereotype.Component;

@Component
public class Car implements Vehicle{

	public String modeOfTransport() {
		// TODO Auto-generated method stub
		return "CAR is ready to go";
	}
	
}
