package com.niit.DependencyInjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		//Traveller traveller=new Traveller(); //Component
		//Auto auto=new Auto();//@Component
		//traveller.setAuto(auto);//@Autowired//setting the dependent object to the traveller
		//System.out.println(traveller.getTravelDetails());
		
		ApplicationContext context=new AnnotationConfigApplicationContext(ConfigurationClazz.class);
		Traveller traveller=(Traveller)context.getBean("traveller");
		System.out.println(traveller.getTravelDetails());		
	}
}