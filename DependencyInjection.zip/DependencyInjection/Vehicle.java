package com.niit.DependencyInjection;

public interface Vehicle {
	public String modeOfTransport();
}
