package com.niit.DependencyInjection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

//traveller depends on auto
//traveller has-a auto
//traveller is-a auto when inherting
@Component //Traveller traveller = new Traveller();

public class Traveller {
	
	public Traveller(){
		System.out.println("TRAVELLER is created");
	}
	//tells the container search for the bean of type Auto
	//and if it finds any bean of type Auto, autowire, inject dependency injection
@Autowired
@Qualifier("auto")
private Vehicle vehicle;	

public Vehicle getVehicle() {
	return vehicle;
}
public void setVehicle(Vehicle vehicle) {
	this.vehicle = vehicle;
}
public String getTravelDetails(){
	return vehicle.modeOfTransport();
}
}
