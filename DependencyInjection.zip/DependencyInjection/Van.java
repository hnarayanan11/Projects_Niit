package com.niit.DependencyInjection;

import org.springframework.stereotype.Component;

@Component
public class Van implements Vehicle{

	public String modeOfTransport() {
		// TODO Auto-generated method stub
		return "VAN is vehicle to transport per km 1000rs";
	}
	
}
