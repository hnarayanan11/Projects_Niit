package com.niit.DependencyInjection;

import org.springframework.stereotype.Component;

@Component //Auto auto=new Auto();
public class Auto implements Vehicle{
	public String modeOfTransport(){
		
		return "Mode of transport is auto rate per km is 10rs";
	}
}
