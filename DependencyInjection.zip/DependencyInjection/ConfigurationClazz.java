package com.niit.DependencyInjection;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//@Configuration class tell the container that it has some bean configuration details
//tell the container, scan all the components in the give package and create beans
//what are components?
//how many components are there in the package com.niit.DependencyInjection
@ComponentScan(basePackages="com.niit.DependencyInjection")
public class ConfigurationClazz {

}
