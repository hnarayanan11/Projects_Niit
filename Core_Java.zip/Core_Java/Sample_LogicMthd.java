
public class Sample_LogicMthd {
	public static void main(String[] args) {
		StringBuffer b=new StringBuffer("Java Sample ");System.out.println(b);
		b.append("Program");
		System.out.println(b);
		StringBuilder b1=new StringBuilder();
		b1.append("sample");
	}

}