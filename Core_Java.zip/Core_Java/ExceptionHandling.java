import java.io.*;
import java.util.Scanner;
public class ExceptionHandling {
public static void main(String[] args)throws IOException {
	int a,b,c;Scanner s=new Scanner(System.in);
	try{
		a=s.nextInt();b=s.nextInt();c=a/b;
		System.out.println("Division: " + c);
	}catch(Exception e){System.out.println(e);}s.close();
}
}