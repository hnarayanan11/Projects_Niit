
public class MethodImplInherit implements com.niit.InterfaceInherit{

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("Switched ON!");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("Switched OFF!");
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("Pluged in and Charging!");
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("Inherited interface method is displayed");
	}
public static void main(String[] args) {
	MethodImplInherit ne=new MethodImplInherit();
	ne.show();
}
}
