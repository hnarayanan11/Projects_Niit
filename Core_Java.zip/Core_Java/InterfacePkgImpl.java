import java.util.Scanner;

import com.niit.*;
public class InterfacePkgImpl implements InterfaceMethod {

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("IMPL swtiched on!");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("IMPL swtiched off!");
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("IMPL swtiched charge!");
	}
public static void main(String[] args) {
	System.out.println("\t\t\t  Interface Implementation"
					+ "\n\t\t\t _*_*_*_*_*_*_*_*_*_*_*_*_*_");int ch;String c;
	Scanner s=new Scanner(System.in); InterfacePkgImpl ii=new InterfacePkgImpl();
	do{
		System.out.println("Enter your\n\t\t 1 to switch on"
				+ "\n\t\t 2 to switch off"
				+ "\n\t\t 3 to charge"
				+ "\n\t\t 4 to exit"); ch=s.nextInt();
		switch (ch){
		case 1: 
			ii.on(); System.out.println("Switched ON!");System.out.println("do you want to enable the charge(y/n)?");c=s.next();
			if(c.equalsIgnoreCase("y")){ii.charge();System.out.println("Pluged in and charging!");}else {break;}
		break;
		case 2:
			ii.off();System.out.println("Switched OFF!");System.out.println("do you want to enable the charge(y/n)?");c=s.next();
			if(c.equalsIgnoreCase("y")){ii.charge();System.out.println("Pluged in and charging!");}else {break;}
		break;
		case 3:
			ii.charge();System.out.println("Pluged in and chargning");
		break;
		}
	}while(ch<4);
	s.close();	
}
}
