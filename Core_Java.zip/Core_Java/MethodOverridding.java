
class SuperClass
{
	void display(){
		// TODO Auto-generated method stub
		System.out.println("Parent Class"); 
	}
}class SubClass extends SuperClass{
	void display(){
		// TODO Auto-generated method stub
		System.out.println("Child Class"); 
	}
}
public class MethodOverridding{
	public static void main(String[] args) {
		System.out.println("\t\t Method Overridding");
		SubClass ss=new SubClass();
		ss.display();	
		SuperClass s=new SuperClass();
		s.display();
	}	
}