
class Sample{
	public final int a=10;
	public final void dispaly(){
		System.out.println("Sample(Parent) Class");
	}
}
class Sample1 extends Sample_LogicMthd{
	/*public void dispaly(){
		System.out.println("Sample1(Child) Class");
	} error in override final method in super class*/
}
final class Sample2{
	public void display(){
		System.out.println("Sample2(Parent) Class");
	}
}/*class Sample3 extends Sample2{
	void display(){System.out.println("Sample3(Child) Class");}
} error to extend the final class*/
public class MethodFinal {
public static void main(String[] args) {
	System.out.println("\t\t Final Variable, Method & Class");
	Sample sam=new Sample();
	sam.dispaly();
	/*sam.a=100; error in changing value for final variable*/
	System.out.println(sam.a);
	Sample2 sa=new Sample2(); sa.display();
}
}
