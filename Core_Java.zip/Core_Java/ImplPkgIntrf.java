
public class ImplPkgIntrf implements com.niit.InterfaceMethod,com.niit.InterfaceMethod2 {

	
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("Switched ON!");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("Switched OFF!");
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("Switched Pluged in & Charging!");
	}
	public int add(int a,int b){
		int c;
		c=a+b;
		return c;		
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Implementation of Print from InterfaceMethod2");
	}
public static void main(String[] args) {
	ImplPkgIntrf ipi=new ImplPkgIntrf();
	System.out.println("ON : ");ipi.on();
	System.out.println("OFF : ");ipi.off();
	System.out.println("CHARGE : ");ipi.charge();
	ipi.add(10,20);}

}
