package com.logics;

import java.util.Scanner;

public class Fibanocci {
public static void main(String[] args) {
	int a=0,b=0,i,c=1,n;
	System.out.println("Enter the Number for fibonacci series:");
	Scanner s=new Scanner(System.in);n=s.nextInt();
	for(i=0;i<n;i++){
		a=b;
		b=c;
		c=a+b;
		System.out.println(a);s.close();
	}
}
}
