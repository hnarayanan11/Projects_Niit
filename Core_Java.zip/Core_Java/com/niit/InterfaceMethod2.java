package com.niit;

public interface InterfaceMethod2 {
void print();
}
