package com.niit;

public interface InterfaceInherit extends InterfaceMethod {
	void show();
}
