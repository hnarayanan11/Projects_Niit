
public class InterfaceImpl implements MethodInterface{

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("fan switched on...!");
		
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("fan switched off...!");
		
	}

	@Override
	public void charge() {
		// TODO Auto-generated method stub
		System.out.println("fan charging...!");
		
	}
public static void main(String[] args) {
	InterfaceImpl ii=new InterfaceImpl();
	ii.on();ii.off();ii.charge();
}
}
