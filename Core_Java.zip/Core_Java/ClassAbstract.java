
abstract class abstract_class{
	abstract void on(); abstract void off(); abstract void chrage();
}
class fan extends abstract_class{

	@Override
	void on() {
		// TODO Auto-generated method stub
		System.out.println("fan switched ON!");
		
	}

	@Override
	void off() {
		// TODO Auto-generated method stub
		System.out.println("fan switched OFF!");
	}

	@Override
	void chrage() {
		// TODO Auto-generated method stub
		System.out.println("fan Pluged IN and Charging!");
	}
	
}
public class ClassAbstract {
public static void main(String[] args) {
	fan f=new fan();
	System.out.println("ON: ");f.on();System.out.println("OFF: ");f.off();System.out.println("CHARGE: ");f.chrage();
}
}
