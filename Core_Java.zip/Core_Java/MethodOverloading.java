
public class MethodOverloading {
public void display(){
	System.out.println("Default Parameter Display Method");	
}
public void display(int a){
	System.out.println("Parameterized Display Method with integer value: "+ a);	
}
public static void main(String[] args) {
	System.out.println("\t\t Method Overloading");
	MethodOverloading mol=new MethodOverloading();
	mol.display();
	mol.display(10);
}
}