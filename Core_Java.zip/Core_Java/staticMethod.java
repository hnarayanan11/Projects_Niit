class Sample_1{
	Sample_1(){
		System.out.println("Constractor Method");
	}
	public static void show(){
		System.out.println("Static Method");
	}
	void display(){
		System.out.println("Normal Method");
	}
}
public class staticMethod {
	public static void main(String[] args) {
		Sample_1 s=new Sample_1();
		Sample_1.show();
		s.display();
	}
}